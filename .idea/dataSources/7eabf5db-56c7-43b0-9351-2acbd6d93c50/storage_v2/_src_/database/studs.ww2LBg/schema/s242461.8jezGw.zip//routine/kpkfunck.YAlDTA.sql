create function kpkfunck()
  returns trigger
language plpgsql
as $$
begin
      insert into "СОСТ_КПК" values (new."ИД_КПК",'исправно',current_timestamp);
      return new;
    end;
$$;

alter function kpkfunck()
  owner to s242461;

