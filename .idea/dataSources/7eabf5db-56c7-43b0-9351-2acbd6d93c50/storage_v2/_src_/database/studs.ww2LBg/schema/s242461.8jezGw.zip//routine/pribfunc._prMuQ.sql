create function pribfunc()
  returns trigger
language plpgsql
as $$
begin
    insert  into "ЛОГ_ПРИБ" values (old."ИД_ПРИБ",new."ПОКАЗАНИЯ",current_timestamp);
    return new;
  end;
$$;

alter function pribfunc()
  owner to s242461;

